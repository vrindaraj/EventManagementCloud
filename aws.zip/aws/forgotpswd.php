<html>
    <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Forgot Password</title>
      
        <body>
            <div class="forgot">
                <h1>FORGOT PASSWORD</h1>
                <p>No Problem! Please enter your email id or username here and we will send you the instructions to reset the password.</p>
                <input type="text" name="" placeholder="Email_id or Username">
                <button type="submit" value="Login">SEND RESET LINK</button>
                <a href="kite_login.php" >Back to Login</a>
            </div>
            <style>
                body{
                    margin: 0%;
                    padding: 0%;
                    font-family: Arial, Helvetica, sans-serif;
                    background-size: cover;
                    background: rgba(0, 0, 0, .2);
                
                }
                .forgot {
                    width: 40%;
                    height: 60%;
                    background: whitesmoke;
                    color: #000000;
                    top: 50%;
	                left: 50%;
	                position: absolute;
	                transform: translate(-50%,-50%);
	                box-sizing: border-box;
	                padding: 70px 30px;

                }
                .forgot h1 {
                    margin: 0;
	                padding: 0 0 20px;
	                text-align: center;
	                font-size: 28px;
                }
                .forgot input {
                    width: 100%;
	                margin-bottom: 40px;
                    border: none;
	                border-bottom: 1px solid #000;
	                background: transparent;
	                outline: none;
	                height: 40px;
	                color: #fff;
	                font-size: 16px;
                }
                .forgot button {
                    border: none;
	                outline: none;
	                height: 40px;
	                width: 100%;
	                background: green;
	                color: #000;
	                font-size: 22px;
	                font-family: times new roman;
	                border-radius: 20px;
                }
                .forgot button:hover {
                    cursor: pointer;
                    background: lightslategrey;
                    color: black;
                }

                .forgot a {
                    padding: 200px;
	                font-size: 22px;
	                line-height: 70px;
	                color: black;

                }

                .forgot a:hover {
                    color: blue;
                }
            </style>
        </body>
    </head>
</html>
<?php
?>
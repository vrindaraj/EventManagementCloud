<!Doctype>
<html>
<title>report generation</title>

<head>
    <meta name="viewport" content="width= device-width, initial-scale=1.0">
    <script>
        function kitereport() {
            var ColumnHead = "Column Header Text";
            var headers = ["Student Name\t Class\t Event-name\t Event-type\t Venue\t Startdate\t End-date"];
            window.open('data:application/vnd.ms-excel,' + headers);
            //e.preventDefault();
        }
    </script>
</head>

<body>
    <div class="container">
        <form id="report" action="">
            <label for="class">Class</label>
            <select id="class" name="class">
                <option value="cse">B.E.CSE</option>
                <option value="it">B.TECH I.T</option>
                <option value="ece">B.E.ECE</option>
                <option value="civil">BE CIVIL</option>
                <option value="mech">B.E.MECHANICAL</option>
            </select>


            <label for="ename">Event Name</label>
            <input type="text" id="lname" name="ename" placeholder="">
            <label for="Event_type">Event type</label>
            <select id="Event_type" name="etype">
                <option value="Workshop">Workshop</option>
                <option value="Symposium">Technical Symposium</option>
                <option value="Conferences">Conferences</option>
                <option value="Paper Presentations">Paper Presentations</option>
                <option value="Hackathon">Hackathon</option>
                <option value="Hackathon">Seminars</option>
                <option value="Hackathon">Placements</option>
            </select>
            <label for="date">From</label>
            <input type="date" id="date" name="from">
            <label for="date">To</label>
            <input type="date" id="date" name="to">
            <button type="button" onclick="kitereport()">generate</button>
        </form>
    </div>
    <style>
        .container {
            padding: auto;
            margin: auto;
            border-radius: 5px;
            background-color: #f2f2f2;
            height: 50%;
            width: 70%;
            text-align: left;
        }

         select, label
         {
            width: 25%;
            padding: 12px;
            border: 1px solid #ccc;
            margin-top: 6px;
            margin-bottom: 16px;
            resize: vertical;
            outline: none;
            border: none;

        }
        input[type="text"],input[type="date"], button
        {
            padding: 10px;
            width: 180px;
            margin: 10px
        }
    </style>
</body>

</html>
<?php
         include 'db_connect.php';
		 if(isset($_POST['submit'])){
			$class = $_POST['class'];
			$ename= $_POST['ename'];
$etype = $_POST['etype'];
$from = $_POST['from'];
$to= $_POST['to'];

$sql = "INSERT INTO kitereport (class,ename,etype,from,to) VALUES ('$class','$ename','$etype','$from','$to')";
//print_r($sql);exit;
            if (mysqli_query($conn, $sql)) {
               echo "New record created successfully";
			  // header("location:kite_login.php");
         } else {
               //echo "Error: " . $sql . "" . mysqli_error($conn);
            }
           


	
        }
      ?>
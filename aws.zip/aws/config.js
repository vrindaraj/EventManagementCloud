window._config = {
    cognito: {
        userPoolId: 'ap-south-1_QyKO5yzks', 
        userPoolClientId: '5dtts35vo71qu5ebg6te2fgseo', 
        region: 'ap-south-1' 
    },
    api: {
        invokeUrl: 'http://kitestudent.com.s3-website-ap-south-1.amazonaws.com' ,
    }
};